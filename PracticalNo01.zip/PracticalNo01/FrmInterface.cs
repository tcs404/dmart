﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PracticalNo01
{
    public partial class FrmInterface : Form
    {
        Transaction t1 = null;
        public FrmInterface()
        {
            InitializeComponent();
        }

        private void FrmInterface_Load(object sender, EventArgs e)
        {
            label5.Text = "";
            label6.Text = "";
            label7.Text = "";
        }

        private void btnCreate_Click(object sender, EventArgs e)
        {
            try
            {
                int id = Convert.ToInt32(txtTID.Text);
                string dt = txtTDate.Text;
                double amt = Convert.ToDouble(txtTAmount.Text);

                t1 = new Transaction(id, dt, amt);
                MessageBox.Show("Transaction done Successfully!!");
            }
            catch(Exception ex)
            {
                MessageBox.Show("Exception Caught!!" + ex.Message);
            }

        }

        private void btnShow_Click(object sender, EventArgs e)
        {
            try
            {
                label5.Text = "   Transaction ID : " + t1.getID().ToString();
                label6.Text = " Transaction Date : " + t1.getDate();
                label7.Text = " Transaction Amount : " + t1.getAmount().ToString();
            }
            catch(Exception ex)
            {
                MessageBox.Show("Exception Caught!!"+ex.Message);
            }

        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtTID.Clear();
            txtTDate.Clear();
            txtTAmount.Clear();
            label5.Text = "";
            label6.Text = "";
            label7.Text = "";
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
    public interface ITransactions
    {
        //interface members
        int getID();
         string getDate();
        double getAmount();

    }
    public class Transaction: ITransactions
    {
        private int id;
        private string date;
        private double amount;
        public Transaction()
        {
            //default constructer
            id = 0;
            date = "";
            amount = 0.0;
        }
        public Transaction(int i,string d,double a)
        {
            id = i;
            date = d;
            amount = a;
        }
        public int getID()
        {
            return id;
        }
        public string getDate()
        {
            return date;
        }
        public double getAmount()
        {
            return amount;
        }
    }
}

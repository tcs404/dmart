﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PracticalNo01
{
    public partial class FrmStringManipulation : Form
    {
        public FrmStringManipulation()
        {
            InitializeComponent();
        }

        private void btnLength_Click(object sender, EventArgs e)
        {
            string txt1 = txtString1.Text;
            string txt2 = txtString2.Text;
            int l,l2;
            l = txt1.Length;
            l2 = txt2.Length;
            l = txt1.Replace(" ", "").Length;
            l2 = txt2.Replace(" ", "").Length;
            txtOutput.Text = "Textbox1 Length="+l.ToString() +", Textbox2 Length= "+l2.ToString();

        }

        private void btnCount_Click(object sender, EventArgs e)
        {
            string words = txtString1.Text.Trim();
            string words1 = txtString2.Text.Trim();
            MessageBox.Show("Number of words: " + CountWords(words)+" ,"+ CountWords1(words1));
        }
        private int CountWords(string words)
        {
            String[] allwords = words.Split(' ');
            return allwords.Length;
        }
        private int CountWords1(string words1)
        {
            String[] allwords1 = words1.Split(' ');
            return allwords1.Length;
        }


        private void btnLower_Click(object sender, EventArgs e)
        {
            string txt1 = txtString1.Text;
            string txt2 = txtString2.Text;
            txtOutput.Text = txt1.ToLower()+ " "+txt2.ToLower();
        }

        private void btnUpper_Click(object sender, EventArgs e)
        {
            string txt1 = txtString1.Text;
            string txt2= txtString2.Text;
            txtOutput.Text = txt1.ToUpper()+" "+txt2.ToUpper();
        }

        private void btnJoinString_Click(object sender, EventArgs e)
        {
            string msg = "Heyy !!";
            string txt1 = txtString1.Text;
            string txt2 = txtString2.Text;


            txtOutput.Text = msg + " " + txt1 + " " + txt2;
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtString1.Clear();
            txtString2.Clear();
            txtOutput.Clear();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}

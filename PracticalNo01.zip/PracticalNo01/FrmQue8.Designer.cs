﻿
namespace PracticalNo01
{
    partial class FrmQue8
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblfullname = new System.Windows.Forms.Label();
            this.lbllongdate = new System.Windows.Forms.Label();
            this.lblshortdate = new System.Windows.Forms.Label();
            this.lblgeneral = new System.Windows.Forms.Label();
            this.lbllongtime = new System.Windows.Forms.Label();
            this.lblshorttime = new System.Windows.Forms.Label();
            this.lbldays = new System.Windows.Forms.Label();
            this.txtfullname = new System.Windows.Forms.TextBox();
            this.txtlongdate = new System.Windows.Forms.TextBox();
            this.txtshortdate = new System.Windows.Forms.TextBox();
            this.txtgeneral = new System.Windows.Forms.TextBox();
            this.txtlongtime = new System.Windows.Forms.TextBox();
            this.txtshorttime = new System.Windows.Forms.TextBox();
            this.txtdays = new System.Windows.Forms.TextBox();
            this.btnrefresh = new System.Windows.Forms.Button();
            this.btnclose = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblfullname
            // 
            this.lblfullname.AutoSize = true;
            this.lblfullname.Location = new System.Drawing.Point(79, 70);
            this.lblfullname.Name = "lblfullname";
            this.lblfullname.Size = new System.Drawing.Size(136, 17);
            this.lblfullname.TabIndex = 0;
            this.lblfullname.Text = "Full Date And Time :";
            // 
            // lbllongdate
            // 
            this.lbllongdate.AutoSize = true;
            this.lbllongdate.Location = new System.Drawing.Point(79, 110);
            this.lbllongdate.Name = "lbllongdate";
            this.lbllongdate.Size = new System.Drawing.Size(82, 17);
            this.lbllongdate.TabIndex = 1;
            this.lbllongdate.Text = "Long Date :";
            // 
            // lblshortdate
            // 
            this.lblshortdate.AutoSize = true;
            this.lblshortdate.Location = new System.Drawing.Point(79, 155);
            this.lblshortdate.Name = "lblshortdate";
            this.lblshortdate.Size = new System.Drawing.Size(84, 17);
            this.lblshortdate.TabIndex = 2;
            this.lblshortdate.Text = "Short Date :";
            // 
            // lblgeneral
            // 
            this.lblgeneral.AutoSize = true;
            this.lblgeneral.Location = new System.Drawing.Point(79, 201);
            this.lblgeneral.Name = "lblgeneral";
            this.lblgeneral.Size = new System.Drawing.Size(165, 17);
            this.lblgeneral.TabIndex = 3;
            this.lblgeneral.Text = "General Date And Time :";
            // 
            // lbllongtime
            // 
            this.lbllongtime.AutoSize = true;
            this.lbllongtime.Location = new System.Drawing.Point(79, 245);
            this.lbllongtime.Name = "lbllongtime";
            this.lbllongtime.Size = new System.Drawing.Size(87, 17);
            this.lbllongtime.TabIndex = 4;
            this.lbllongtime.Text = "Long Time : ";
            // 
            // lblshorttime
            // 
            this.lblshorttime.AutoSize = true;
            this.lblshorttime.Location = new System.Drawing.Point(79, 293);
            this.lblshorttime.Name = "lblshorttime";
            this.lblshorttime.Size = new System.Drawing.Size(89, 17);
            this.lblshorttime.TabIndex = 5;
            this.lblshorttime.Text = "Short Time : ";
            // 
            // lbldays
            // 
            this.lbldays.AutoSize = true;
            this.lbldays.Location = new System.Drawing.Point(79, 342);
            this.lbldays.Name = "lbldays";
            this.lbldays.Size = new System.Drawing.Size(145, 17);
            this.lbldays.TabIndex = 6;
            this.lbldays.Text = "Days Until New Year :";
            // 
            // txtfullname
            // 
            this.txtfullname.Location = new System.Drawing.Point(237, 67);
            this.txtfullname.Name = "txtfullname";
            this.txtfullname.Size = new System.Drawing.Size(263, 22);
            this.txtfullname.TabIndex = 7;
            // 
            // txtlongdate
            // 
            this.txtlongdate.Location = new System.Drawing.Point(237, 107);
            this.txtlongdate.Name = "txtlongdate";
            this.txtlongdate.Size = new System.Drawing.Size(263, 22);
            this.txtlongdate.TabIndex = 8;
            // 
            // txtshortdate
            // 
            this.txtshortdate.Location = new System.Drawing.Point(237, 150);
            this.txtshortdate.Name = "txtshortdate";
            this.txtshortdate.Size = new System.Drawing.Size(263, 22);
            this.txtshortdate.TabIndex = 9;
            // 
            // txtgeneral
            // 
            this.txtgeneral.Location = new System.Drawing.Point(237, 201);
            this.txtgeneral.Name = "txtgeneral";
            this.txtgeneral.Size = new System.Drawing.Size(263, 22);
            this.txtgeneral.TabIndex = 10;
            // 
            // txtlongtime
            // 
            this.txtlongtime.Location = new System.Drawing.Point(237, 245);
            this.txtlongtime.Name = "txtlongtime";
            this.txtlongtime.Size = new System.Drawing.Size(263, 22);
            this.txtlongtime.TabIndex = 11;
            // 
            // txtshorttime
            // 
            this.txtshorttime.Location = new System.Drawing.Point(237, 293);
            this.txtshorttime.Name = "txtshorttime";
            this.txtshorttime.Size = new System.Drawing.Size(263, 22);
            this.txtshorttime.TabIndex = 12;
            // 
            // txtdays
            // 
            this.txtdays.Location = new System.Drawing.Point(237, 342);
            this.txtdays.Name = "txtdays";
            this.txtdays.Size = new System.Drawing.Size(263, 22);
            this.txtdays.TabIndex = 13;
            // 
            // btnrefresh
            // 
            this.btnrefresh.Location = new System.Drawing.Point(116, 416);
            this.btnrefresh.Name = "btnrefresh";
            this.btnrefresh.Size = new System.Drawing.Size(99, 46);
            this.btnrefresh.TabIndex = 14;
            this.btnrefresh.Text = "Refresh";
            this.btnrefresh.UseVisualStyleBackColor = true;
            this.btnrefresh.Click += new System.EventHandler(this.btnrefresh_Click);
            // 
            // btnclose
            // 
            this.btnclose.Location = new System.Drawing.Point(303, 415);
            this.btnclose.Name = "btnclose";
            this.btnclose.Size = new System.Drawing.Size(85, 47);
            this.btnclose.TabIndex = 15;
            this.btnclose.Text = "Close";
            this.btnclose.UseVisualStyleBackColor = true;
            this.btnclose.Click += new System.EventHandler(this.btnclose_Click);
            // 
            // FrmQue8
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(849, 538);
            this.Controls.Add(this.btnclose);
            this.Controls.Add(this.btnrefresh);
            this.Controls.Add(this.txtdays);
            this.Controls.Add(this.txtshorttime);
            this.Controls.Add(this.txtlongtime);
            this.Controls.Add(this.txtgeneral);
            this.Controls.Add(this.txtshortdate);
            this.Controls.Add(this.txtlongdate);
            this.Controls.Add(this.txtfullname);
            this.Controls.Add(this.lbldays);
            this.Controls.Add(this.lblshorttime);
            this.Controls.Add(this.lbllongtime);
            this.Controls.Add(this.lblgeneral);
            this.Controls.Add(this.lblshortdate);
            this.Controls.Add(this.lbllongdate);
            this.Controls.Add(this.lblfullname);
            this.Name = "FrmQue8";
            this.Text = "FrmQue8";
            this.Load += new System.EventHandler(this.FrmQue8_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblfullname;
        private System.Windows.Forms.Label lbllongdate;
        private System.Windows.Forms.Label lblshortdate;
        private System.Windows.Forms.Label lblgeneral;
        private System.Windows.Forms.Label lbllongtime;
        private System.Windows.Forms.Label lblshorttime;
        private System.Windows.Forms.Label lbldays;
        private System.Windows.Forms.TextBox txtfullname;
        private System.Windows.Forms.TextBox txtlongdate;
        private System.Windows.Forms.TextBox txtshortdate;
        private System.Windows.Forms.TextBox txtgeneral;
        private System.Windows.Forms.TextBox txtlongtime;
        private System.Windows.Forms.TextBox txtshorttime;
        private System.Windows.Forms.TextBox txtdays;
        private System.Windows.Forms.Button btnrefresh;
        private System.Windows.Forms.Button btnclose;
    }
}
﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PracticalNo01
{
    public partial class Details : Form
    {
        public string firstName { get; set; }
        public string middleName { get; set; }
        public string lastName { get; set; }
        public string dob { get; set; }
        public string mob { get; set; }
        public string address { get; set; }
        public string username { get; set; }
        public string passowrd { get; set; }
        public string gender { get; set; }
        public bool Checked { get; set; }
        public string path { get; set; }
        public string hobbies { get; set; }
        public string city { get; set; }
        public Details()
        {
            InitializeComponent();
        }

        private void Details_Load(object sender, EventArgs e)
        {

            lblfirst.Text = "First Name: " + firstName;
            lblmiddle.Text = "Middle Name: " + middleName;
            lbllast.Text = "Last Name: " + lastName;
            lbldob.Text = "Date Of Birth: " + dob;
            lblmob.Text = "Mobile Number: " + mob;
            lbladdress.Text = "Address: " + address;
            lblusername.Text = "Username: " + username;
            lblpass.Text = "Password: " + passowrd;
            lblgender.Text = "Gender: " + gender;
            picbox.ImageLocation = path;
            lblhobby.Text = hobbies;
            lblcity.Text = "City: " + city;
        }
    }
}

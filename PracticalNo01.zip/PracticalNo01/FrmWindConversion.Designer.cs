﻿
namespace PracticalNo01
{
    partial class FrmWindConversion
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.lblknots = new System.Windows.Forms.Label();
            this.txtKnots = new System.Windows.Forms.TextBox();
            this.btnMph = new System.Windows.Forms.Button();
            this.btnKph = new System.Windows.Forms.Button();
            this.lblMsg = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("MS Reference Sans Serif", 10.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(330, 34);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(170, 22);
            this.label1.TabIndex = 0;
            this.label1.Text = "Wind Conversion";
            // 
            // lblknots
            // 
            this.lblknots.AutoSize = true;
            this.lblknots.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblknots.Location = new System.Drawing.Point(153, 111);
            this.lblknots.Name = "lblknots";
            this.lblknots.Size = new System.Drawing.Size(177, 20);
            this.lblknots.TabIndex = 1;
            this.lblknots.Text = "Enter Speed in Knots :";
            // 
            // txtKnots
            // 
            this.txtKnots.Location = new System.Drawing.Point(350, 111);
            this.txtKnots.Name = "txtKnots";
            this.txtKnots.Size = new System.Drawing.Size(187, 22);
            this.txtKnots.TabIndex = 2;
            // 
            // btnMph
            // 
            this.btnMph.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMph.Location = new System.Drawing.Point(229, 191);
            this.btnMph.Name = "btnMph";
            this.btnMph.Size = new System.Drawing.Size(101, 50);
            this.btnMph.TabIndex = 3;
            this.btnMph.Text = "Mph";
            this.btnMph.UseVisualStyleBackColor = true;
            this.btnMph.Click += new System.EventHandler(this.btnMph_Click);
            // 
            // btnKph
            // 
            this.btnKph.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnKph.Location = new System.Drawing.Point(390, 191);
            this.btnKph.Name = "btnKph";
            this.btnKph.Size = new System.Drawing.Size(93, 51);
            this.btnKph.TabIndex = 4;
            this.btnKph.Text = "Kph";
            this.btnKph.UseVisualStyleBackColor = true;
            this.btnKph.Click += new System.EventHandler(this.btnKph_Click);
            // 
            // lblMsg
            // 
            this.lblMsg.AutoSize = true;
            this.lblMsg.Location = new System.Drawing.Point(320, 288);
            this.lblMsg.Name = "lblMsg";
            this.lblMsg.Size = new System.Drawing.Size(54, 17);
            this.lblMsg.TabIndex = 5;
            this.lblMsg.Text = "Answer";
            // 
            // FrmWindConversion
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lblMsg);
            this.Controls.Add(this.btnKph);
            this.Controls.Add(this.btnMph);
            this.Controls.Add(this.txtKnots);
            this.Controls.Add(this.lblknots);
            this.Controls.Add(this.label1);
            this.Name = "FrmWindConversion";
            this.Text = "FrmWindConversion";
            this.Load += new System.EventHandler(this.FrmWindConversion_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblknots;
        private System.Windows.Forms.TextBox txtKnots;
        private System.Windows.Forms.Button btnMph;
        private System.Windows.Forms.Button btnKph;
        private System.Windows.Forms.Label lblMsg;
    }
}
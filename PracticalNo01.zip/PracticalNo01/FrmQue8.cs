﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PracticalNo01
{
    public partial class FrmQue8 : Form
    {
        DateTime d = new DateTime();
        public FrmQue8()
        {
            InitializeComponent();
        }

        private void FrmQue8_Load(object sender, EventArgs e)
        {

        }

        private void btnrefresh_Click(object sender, EventArgs e)
        {

            d = DateTime.Now;
            txtfullname.Text = d.ToString("dddd, MMMM dd yyyy HH:mm:ss tt");
            txtlongdate.Text = d.ToLongDateString();
            txtshortdate.Text = d.ToString("dd-MMM-yy");
            txtgeneral.Text = d.ToString(" dd-MMM-yy HH:mm tt");
            txtlongtime.Text = d.ToLongTimeString();
            txtshorttime.Text = d.ToShortTimeString();
            int noOfDays = DateTime.IsLeapYear(DateTime.Now.Year) ? 366 : 365;
            txtdays.Text = (noOfDays - DateTime.Now.DayOfYear).ToString();
            //int remdays = 365 - d.DayOfYear;
            //txtdays.Text = Convert.ToString(remdays);

            txtfullname.Enabled = true;
            txtlongdate.Enabled = false;
            txtshortdate.Enabled = false;
            txtgeneral.Enabled = false;
            txtlongtime.Enabled = false;
            txtshorttime.Enabled = false;
            txtdays.Enabled = false;
        }

        private void btnclose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PracticalNo01
{
    public partial class FrmAbstractClass : Form
    {
        Rectangle r1 = null;
        Triangle t1 = null;
        public FrmAbstractClass()
        {
            InitializeComponent();
        }

        private void FrmAbstractClass_Load(object sender, EventArgs e)
        {
            label2.Text = "";
            label3.Text = "";
            lblAnswer.Text = "";
            lblMessage.Text = "";
            btnAreaRectangle.Enabled = false;
            btnAreaTriangle.Enabled = false;
        }
        private void rbRectangle_CheckedChanged(object sender, EventArgs e)
        {
            label2.Text = " Enter length : ";
            label3.Text = " Enter width : ";
            btnAreaRectangle.Enabled = true;
            btnAreaTriangle.Enabled = false;
        }

        private void rbTriangle_CheckedChanged(object sender, EventArgs e)
        {
            label2.Text = " Enter base: ";
            label3.Text = " Enter height : ";
            btnAreaRectangle.Enabled = false;
            btnAreaTriangle.Enabled = true;
        }

        

        private void btnClear_Click(object sender, EventArgs e)
        {
           textBox1.Text = " ";
            textBox2.Text = " ";
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnAreaRectangle_Click(object sender, EventArgs e)
        {
            int l = Convert.ToInt32(textBox1.Text);
            int w = Convert.ToInt32(textBox2.Text);
            r1 = new Rectangle(l, w);
            lblAnswer.Text = "Area of Rectangle = " + r1.area().ToString();
            lblMessage.Text = r1.show();
        }

        private void btnAreaTriangle_Click(object sender, EventArgs e)
        {
            int b = Convert.ToInt32(textBox1.Text);
            int h = Convert.ToInt32(textBox2.Text);
            t1 = new Triangle(b, h);
            lblAnswer.Text = "Area of Triangle = " + t1.area().ToString();
            lblMessage.Text = t1.show();
        }
    }
    abstract class Shape
    {
        public virtual double area()
        {
            return 0;
        }
        public abstract string show();
    }
    class Rectangle : Shape
    {
        private int length;
        private int width;
        public Rectangle(int l =0,int w=0)
        {
            length = l;
            width = w;
        }
        public override double area() //return area of rectangle
        {
            return (width*length);
        }
        public override string show()
        {
            return("Inside Rectangle Class!!");
        }
    }
    class Triangle :Shape
    {
        private int Base;
        private int height;
        public Triangle(int b=0,int h=0)
        {
            Base = b;
            height = h;
        }
        public override double area()
        {
            return (0.5*Base*height);
        }
        public override string show()
        {
            return("Inside Triangle Class!!");
        }
    }
}

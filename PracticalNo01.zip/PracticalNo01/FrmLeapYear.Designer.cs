﻿
namespace PracticalNo01
{
    partial class FrmLeapYear
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.lblYear = new System.Windows.Forms.Label();
            this.lblAnswer = new System.Windows.Forms.Label();
            this.txtYear = new System.Windows.Forms.TextBox();
            this.btnCheck = new System.Windows.Forms.Button();
            this.btnCreateObj = new System.Windows.Forms.Button();
            this.btnClose = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("MingLiU-ExtB", 13.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(344, 33);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(127, 24);
            this.label1.TabIndex = 0;
            this.label1.Text = "LEAP YEAR";
            // 
            // lblYear
            // 
            this.lblYear.AutoSize = true;
            this.lblYear.Location = new System.Drawing.Point(216, 101);
            this.lblYear.Name = "lblYear";
            this.lblYear.Size = new System.Drawing.Size(88, 17);
            this.lblYear.TabIndex = 1;
            this.lblYear.Text = "Enter Year : ";
            // 
            // lblAnswer
            // 
            this.lblAnswer.AutoSize = true;
            this.lblAnswer.Location = new System.Drawing.Point(362, 351);
            this.lblAnswer.Name = "lblAnswer";
            this.lblAnswer.Size = new System.Drawing.Size(54, 17);
            this.lblAnswer.TabIndex = 2;
            this.lblAnswer.Text = "Answer";
            // 
            // txtYear
            // 
            this.txtYear.Location = new System.Drawing.Point(347, 101);
            this.txtYear.Name = "txtYear";
            this.txtYear.Size = new System.Drawing.Size(172, 22);
            this.txtYear.TabIndex = 3;
            // 
            // btnCheck
            // 
            this.btnCheck.Location = new System.Drawing.Point(308, 251);
            this.btnCheck.Name = "btnCheck";
            this.btnCheck.Size = new System.Drawing.Size(174, 77);
            this.btnCheck.TabIndex = 4;
            this.btnCheck.Text = "Click Here to check";
            this.btnCheck.UseVisualStyleBackColor = true;
            this.btnCheck.Click += new System.EventHandler(this.btnCheck_Click);
            // 
            // btnCreateObj
            // 
            this.btnCreateObj.Location = new System.Drawing.Point(330, 173);
            this.btnCreateObj.Name = "btnCreateObj";
            this.btnCreateObj.Size = new System.Drawing.Size(125, 44);
            this.btnCreateObj.TabIndex = 5;
            this.btnCreateObj.Text = "CreateOBJ";
            this.btnCreateObj.UseVisualStyleBackColor = true;
            this.btnCreateObj.Click += new System.EventHandler(this.btnCreateObj_Click);
            // 
            // btnClose
            // 
            this.btnClose.Location = new System.Drawing.Point(523, 251);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(75, 77);
            this.btnClose.TabIndex = 6;
            this.btnClose.Text = "Close";
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // FrmLeapYear
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(755, 433);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.btnCreateObj);
            this.Controls.Add(this.btnCheck);
            this.Controls.Add(this.txtYear);
            this.Controls.Add(this.lblAnswer);
            this.Controls.Add(this.lblYear);
            this.Controls.Add(this.label1);
            this.Name = "FrmLeapYear";
            this.Text = "FrmLeapYear";
            this.Load += new System.EventHandler(this.FrmLeapYear_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblYear;
        private System.Windows.Forms.Label lblAnswer;
        private System.Windows.Forms.TextBox txtYear;
        private System.Windows.Forms.Button btnCheck;
        private System.Windows.Forms.Button btnCreateObj;
        private System.Windows.Forms.Button btnClose;
    }
}
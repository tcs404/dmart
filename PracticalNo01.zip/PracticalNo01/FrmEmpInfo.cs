﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PracticalNo01
{
    public partial class FrmEmpInfo : Form
    {
        Employee e1 = null;
        public FrmEmpInfo()
        {
            InitializeComponent();
        }
        private void FrmEmpInfo_Load(object sender, EventArgs e)
        {
            lblEmpID.Text = "";
            lblEmpName.Text = "";
        }
        private void btnCreateObj_Click(object sender, EventArgs e)
        {
            try
            {
            int eid = Convert.ToInt32(txtEmpID.Text);
            string nm = txtEmpName.Text;
            e1 = new Employee(eid, nm);
            MessageBox.Show("Object Created Successfully!!");
            }
            catch(Exception ex)
            {
                MessageBox.Show("Exception Caught!!" + ex.Message);
            }
            finally
            {
               // MessageBox.Show("It's Finally Block!!");
            }
        }

        private void btnDisplay_Click(object sender, EventArgs e)
        {
            lblEmpID.Text = e1.getEmpID().ToString();
            lblEmpName.Text = e1.getEmpName();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
    class Employee
    {
        int empID;
        string empName;
        public Employee()
        {

        }
        public Employee(int e,string n)
        {
            empID = e;
            empName = n;
        }
        ~Employee()
        {

        }
        public int getEmpID()
        {
            return empID;
        }
        public string getEmpName()
        {
            return empName;
        }
    }
}

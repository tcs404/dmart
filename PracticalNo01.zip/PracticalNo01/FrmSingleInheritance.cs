﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PracticalNo01
{
    public partial class FrmSingleInheritance : Form
    {
        Marks m1 = null;
        public FrmSingleInheritance()
        {
            InitializeComponent();
        }

        private void FrmSingleInheritance_Load(object sender, EventArgs e)
        {

        }

        private void btnCreate_Click(object sender, EventArgs e)
        {
            try
            {
                int rn = Convert.ToInt32(txtRollNo.Text);
                string nm = txtName.Text;
                int m = Convert.ToInt32(txtMaths.Text);
                int p = Convert.ToInt32(txtPhy.Text);
                int c = Convert.ToInt32(txtChem.Text);
                m1 = new Marks(rn, nm, m, p, c);
                MessageBox.Show("Object created successfully!!!");
            }
            catch(Exception ex)
            {
                MessageBox.Show("Exception Caught!!"+ex.Message);
            }
        }

        private void btnDisplay_Click(object sender, EventArgs e)
        {
            try
            {
                double percent = m1.display();
                if(percent==0)
                {
                    lblResult.Text = "Fail!!";
                }
                else
                {
                    lblResult.Text = "Pass!! Total Marks Obtained " +m1.totalMarks()+ " out of 300. ";
                    lblPercentage.Text = "Percentage : " +percent;
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show("Exception Caught!!" + ex.Message);
            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtRollNo.Clear();
            txtName.Clear();
            txtMaths.Clear();
            txtPhy.Clear();
            txtChem.Clear();
            lblResult.Text = "";
            lblPercentage.Text = "";

        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
    public class Student
    {
        protected int rollNo;
        protected string name;
        public Student()
        { }
        public Student(int rollNo,string name)
        {
            this.rollNo = rollNo;
            this.name = name;
        }
        public int getRollNo()
        {
            return rollNo;
        }
        public string getName()
        {
            return name;
        }
     }
    public class Marks: Student//: refers the inheritance here
    {
        //derivrd class (own properties which are not in base class) 
        int mathematics;
        int physics;
        int chemistry;
        public Marks(int rn,string nm,int maths,int phy,int chem): base(rn,nm)//base allows us to envoke the base class constructor
        {
            mathematics = maths;
            physics = phy;
            chemistry = chem;
        }
        public int totalMarks()
        {
            return (mathematics + physics + chemistry);
        }
        public float display()
        {
            if(mathematics<35||physics<35||chemistry<35)
            {
                return 0;
            }
            else
            {
                float percentage = ((mathematics + physics + chemistry) * 100) / 300;
                return percentage;
            }
        }
    }
}

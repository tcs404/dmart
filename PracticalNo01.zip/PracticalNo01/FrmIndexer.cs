﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PracticalNo01
{
    public partial class FrmIndexer : Form
    {
        public FrmIndexer()
        {
            InitializeComponent();
        }



        private void FrmIndexer_Load(object sender, EventArgs e)
        {
        
        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            StringCollection stringCollection = new StringCollection();
            stringCollection[0] = "Banana";
            stringCollection[1] = "Papaya";
            stringCollection[2] = "Dates";
            stringCollection[3] = "Orange";
            stringCollection[4] = "Apple";
            string output = " ";
            for(int i=0;i<stringCollection.Count;i++){
                output += stringCollection[i] + "\n";
            }
            lblOutput.Text = output;
        }
    }
    public class StringCollection
    {
        private string[] strings = new string[10];


        public string this[int index]
        {
            get
            {

                return strings[index];
            }
            set
            {
                strings[index] = value;
            }
        }
            public int Count
        {
            get
            {
                return strings.Length;
            }
        }
        }

    }


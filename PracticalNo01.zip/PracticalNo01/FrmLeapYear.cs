﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PracticalNo01
{
    public partial class FrmLeapYear : Form
    {
        Leapyear l1 = null;

        public FrmLeapYear()
        {
            InitializeComponent();
        }



        private void FrmLeapYear_Load(object sender, EventArgs e)
        {

        }
        private void btnCreateObj_Click(object sender, EventArgs e)
        {
            int year = Convert.ToInt32(txtYear.Text);
            l1 = new Leapyear(year);
            MessageBox.Show("Object created successfully");
        }

        private void btnCheck_Click(object sender, EventArgs e)
        {
          lblAnswer.Text = " The Entered Year is " + l1.Year().ToString();

        }
        class Leapyear
        {
            int year;

            public Leapyear()
            { }

            public Leapyear(int y)
            {
                year = y;
            }
            ~Leapyear()
            { }

            public int Year()
            {
                int lyear = year;


                if (((year % 4 == 0) && (year % 100 != 0)) || (year % 400 == 0))
                {
                    MessageBox.Show("It is a leap year");
                }
                else
                {
                    MessageBox.Show("It is not a leap year");
                }
                return lyear;

            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
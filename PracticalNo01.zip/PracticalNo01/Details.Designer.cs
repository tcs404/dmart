﻿
namespace PracticalNo01
{
    partial class Details
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblhead = new System.Windows.Forms.Label();
            this.lblfirst = new System.Windows.Forms.Label();
            this.lblmiddle = new System.Windows.Forms.Label();
            this.lbllast = new System.Windows.Forms.Label();
            this.lbldob = new System.Windows.Forms.Label();
            this.lblmob = new System.Windows.Forms.Label();
            this.lbladdress = new System.Windows.Forms.Label();
            this.lblcity = new System.Windows.Forms.Label();
            this.lblusername = new System.Windows.Forms.Label();
            this.lblpass = new System.Windows.Forms.Label();
            this.lblgender = new System.Windows.Forms.Label();
            this.lblhobby = new System.Windows.Forms.Label();
            this.picbox = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.picbox)).BeginInit();
            this.SuspendLayout();
            // 
            // lblhead
            // 
            this.lblhead.AutoSize = true;
            this.lblhead.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblhead.Location = new System.Drawing.Point(313, 13);
            this.lblhead.Name = "lblhead";
            this.lblhead.Size = new System.Drawing.Size(188, 24);
            this.lblhead.TabIndex = 0;
            this.lblhead.Text = "Registration Details";
            // 
            // lblfirst
            // 
            this.lblfirst.AutoSize = true;
            this.lblfirst.Location = new System.Drawing.Point(54, 75);
            this.lblfirst.Name = "lblfirst";
            this.lblfirst.Size = new System.Drawing.Size(46, 17);
            this.lblfirst.TabIndex = 1;
            this.lblfirst.Text = "label2";
            // 
            // lblmiddle
            // 
            this.lblmiddle.AutoSize = true;
            this.lblmiddle.Location = new System.Drawing.Point(54, 114);
            this.lblmiddle.Name = "lblmiddle";
            this.lblmiddle.Size = new System.Drawing.Size(46, 17);
            this.lblmiddle.TabIndex = 2;
            this.lblmiddle.Text = "label3";
            // 
            // lbllast
            // 
            this.lbllast.AutoSize = true;
            this.lbllast.Location = new System.Drawing.Point(54, 152);
            this.lbllast.Name = "lbllast";
            this.lbllast.Size = new System.Drawing.Size(46, 17);
            this.lbllast.TabIndex = 3;
            this.lbllast.Text = "label4";
            // 
            // lbldob
            // 
            this.lbldob.AutoSize = true;
            this.lbldob.Location = new System.Drawing.Point(54, 190);
            this.lbldob.Name = "lbldob";
            this.lbldob.Size = new System.Drawing.Size(46, 17);
            this.lbldob.TabIndex = 4;
            this.lbldob.Text = "label5";
            // 
            // lblmob
            // 
            this.lblmob.AutoSize = true;
            this.lblmob.Location = new System.Drawing.Point(54, 225);
            this.lblmob.Name = "lblmob";
            this.lblmob.Size = new System.Drawing.Size(46, 17);
            this.lblmob.TabIndex = 5;
            this.lblmob.Text = "label6";
            // 
            // lbladdress
            // 
            this.lbladdress.AutoSize = true;
            this.lbladdress.Location = new System.Drawing.Point(54, 266);
            this.lbladdress.Name = "lbladdress";
            this.lbladdress.Size = new System.Drawing.Size(46, 17);
            this.lbladdress.TabIndex = 6;
            this.lbladdress.Text = "label7";
            // 
            // lblcity
            // 
            this.lblcity.AutoSize = true;
            this.lblcity.Location = new System.Drawing.Point(54, 311);
            this.lblcity.Name = "lblcity";
            this.lblcity.Size = new System.Drawing.Size(46, 17);
            this.lblcity.TabIndex = 7;
            this.lblcity.Text = "label8";
            // 
            // lblusername
            // 
            this.lblusername.AutoSize = true;
            this.lblusername.Location = new System.Drawing.Point(54, 364);
            this.lblusername.Name = "lblusername";
            this.lblusername.Size = new System.Drawing.Size(46, 17);
            this.lblusername.TabIndex = 8;
            this.lblusername.Text = "label9";
            // 
            // lblpass
            // 
            this.lblpass.AutoSize = true;
            this.lblpass.Location = new System.Drawing.Point(54, 409);
            this.lblpass.Name = "lblpass";
            this.lblpass.Size = new System.Drawing.Size(54, 17);
            this.lblpass.TabIndex = 9;
            this.lblpass.Text = "label10";
            // 
            // lblgender
            // 
            this.lblgender.AutoSize = true;
            this.lblgender.Location = new System.Drawing.Point(54, 454);
            this.lblgender.Name = "lblgender";
            this.lblgender.Size = new System.Drawing.Size(54, 17);
            this.lblgender.TabIndex = 10;
            this.lblgender.Text = "label11";
            // 
            // lblhobby
            // 
            this.lblhobby.AutoSize = true;
            this.lblhobby.Location = new System.Drawing.Point(54, 491);
            this.lblhobby.Name = "lblhobby";
            this.lblhobby.Size = new System.Drawing.Size(54, 17);
            this.lblhobby.TabIndex = 11;
            this.lblhobby.Text = "label12";
            // 
            // picbox
            // 
            this.picbox.Location = new System.Drawing.Point(553, 114);
            this.picbox.Name = "picbox";
            this.picbox.Size = new System.Drawing.Size(272, 280);
            this.picbox.TabIndex = 12;
            this.picbox.TabStop = false;
            // 
            // Details
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(950, 548);
            this.Controls.Add(this.picbox);
            this.Controls.Add(this.lblhobby);
            this.Controls.Add(this.lblgender);
            this.Controls.Add(this.lblpass);
            this.Controls.Add(this.lblusername);
            this.Controls.Add(this.lblcity);
            this.Controls.Add(this.lbladdress);
            this.Controls.Add(this.lblmob);
            this.Controls.Add(this.lbldob);
            this.Controls.Add(this.lbllast);
            this.Controls.Add(this.lblmiddle);
            this.Controls.Add(this.lblfirst);
            this.Controls.Add(this.lblhead);
            this.Name = "Details";
            this.Text = "Details";
            this.Load += new System.EventHandler(this.Details_Load);
            ((System.ComponentModel.ISupportInitialize)(this.picbox)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblhead;
        private System.Windows.Forms.Label lblfirst;
        private System.Windows.Forms.Label lblmiddle;
        private System.Windows.Forms.Label lbllast;
        private System.Windows.Forms.Label lbldob;
        private System.Windows.Forms.Label lblmob;
        private System.Windows.Forms.Label lbladdress;
        private System.Windows.Forms.Label lblcity;
        private System.Windows.Forms.Label lblusername;
        private System.Windows.Forms.Label lblpass;
        private System.Windows.Forms.Label lblgender;
        private System.Windows.Forms.Label lblhobby;
        private System.Windows.Forms.PictureBox picbox;
    }
}
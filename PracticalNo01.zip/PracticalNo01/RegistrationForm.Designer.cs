﻿
namespace PracticalNo01
{
    partial class RegistrationFrom
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.lblfirst = new System.Windows.Forms.Label();
            this.lblmiddle = new System.Windows.Forms.Label();
            this.lbllast = new System.Windows.Forms.Label();
            this.lbldob = new System.Windows.Forms.Label();
            this.lblmobile = new System.Windows.Forms.Label();
            this.lbladdress = new System.Windows.Forms.Label();
            this.lblcity = new System.Windows.Forms.Label();
            this.lbluser = new System.Windows.Forms.Label();
            this.lblpass = new System.Windows.Forms.Label();
            this.btnaddimg = new System.Windows.Forms.Button();
            this.btnsubmit = new System.Windows.Forms.Button();
            this.btnclose = new System.Windows.Forms.Button();
            this.btnclear = new System.Windows.Forms.Button();
            this.txtfirst = new System.Windows.Forms.TextBox();
            this.txtmiddle = new System.Windows.Forms.TextBox();
            this.txtlast = new System.Windows.Forms.TextBox();
            this.dobpicker = new System.Windows.Forms.DateTimePicker();
            this.txtmobile = new System.Windows.Forms.TextBox();
            this.txtuser = new System.Windows.Forms.TextBox();
            this.radiomale = new System.Windows.Forms.RadioButton();
            this.radiofemale = new System.Windows.Forms.RadioButton();
            this.checkhobby = new System.Windows.Forms.CheckedListBox();
            this.image1 = new System.Windows.Forms.PictureBox();
            this.lblgender = new System.Windows.Forms.Label();
            this.lblhobby = new System.Windows.Forms.Label();
            this.txtaddress = new System.Windows.Forms.TextBox();
            this.txtpass = new System.Windows.Forms.TextBox();
            this.citylist = new System.Windows.Forms.ComboBox();
            this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
            ((System.ComponentModel.ISupportInitialize)(this.image1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft YaHei UI", 10.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(460, 21);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(163, 24);
            this.label1.TabIndex = 0;
            this.label1.Text = "Registration Form";
            // 
            // lblfirst
            // 
            this.lblfirst.AutoSize = true;
            this.lblfirst.Location = new System.Drawing.Point(84, 79);
            this.lblfirst.Name = "lblfirst";
            this.lblfirst.Size = new System.Drawing.Size(88, 17);
            this.lblfirst.TabIndex = 1;
            this.lblfirst.Text = "First Name : ";
            // 
            // lblmiddle
            // 
            this.lblmiddle.AutoSize = true;
            this.lblmiddle.Location = new System.Drawing.Point(399, 82);
            this.lblmiddle.Name = "lblmiddle";
            this.lblmiddle.Size = new System.Drawing.Size(102, 17);
            this.lblmiddle.TabIndex = 2;
            this.lblmiddle.Text = "Middle Name : ";
            // 
            // lbllast
            // 
            this.lbllast.AutoSize = true;
            this.lbllast.Location = new System.Drawing.Point(721, 78);
            this.lbllast.Name = "lbllast";
            this.lbllast.Size = new System.Drawing.Size(88, 17);
            this.lbllast.TabIndex = 3;
            this.lbllast.Text = "Last Name : ";
            // 
            // lbldob
            // 
            this.lbldob.AutoSize = true;
            this.lbldob.Location = new System.Drawing.Point(96, 160);
            this.lbldob.Name = "lbldob";
            this.lbldob.Size = new System.Drawing.Size(50, 17);
            this.lbldob.TabIndex = 4;
            this.lbldob.Text = "DOB : ";
            // 
            // lblmobile
            // 
            this.lblmobile.AutoSize = true;
            this.lblmobile.Location = new System.Drawing.Point(399, 160);
            this.lblmobile.Name = "lblmobile";
            this.lblmobile.Size = new System.Drawing.Size(87, 17);
            this.lblmobile.TabIndex = 5;
            this.lblmobile.Text = "Mobile No. : ";
            // 
            // lbladdress
            // 
            this.lbladdress.AutoSize = true;
            this.lbladdress.Location = new System.Drawing.Point(74, 227);
            this.lbladdress.Name = "lbladdress";
            this.lbladdress.Size = new System.Drawing.Size(72, 17);
            this.lbladdress.TabIndex = 6;
            this.lbladdress.Text = "Address : ";
            // 
            // lblcity
            // 
            this.lblcity.AutoSize = true;
            this.lblcity.Location = new System.Drawing.Point(426, 234);
            this.lblcity.Name = "lblcity";
            this.lblcity.Size = new System.Drawing.Size(43, 17);
            this.lblcity.TabIndex = 7;
            this.lblcity.Text = "City : ";
            // 
            // lbluser
            // 
            this.lbluser.AutoSize = true;
            this.lbluser.Location = new System.Drawing.Point(74, 324);
            this.lbluser.Name = "lbluser";
            this.lbluser.Size = new System.Drawing.Size(83, 17);
            this.lbluser.TabIndex = 8;
            this.lbluser.Text = "username : ";
            // 
            // lblpass
            // 
            this.lblpass.AutoSize = true;
            this.lblpass.Location = new System.Drawing.Point(355, 324);
            this.lblpass.Name = "lblpass";
            this.lblpass.Size = new System.Drawing.Size(81, 17);
            this.lblpass.TabIndex = 9;
            this.lblpass.Text = "Password : ";
            // 
            // btnaddimg
            // 
            this.btnaddimg.Location = new System.Drawing.Point(850, 410);
            this.btnaddimg.Name = "btnaddimg";
            this.btnaddimg.Size = new System.Drawing.Size(105, 34);
            this.btnaddimg.TabIndex = 10;
            this.btnaddimg.Text = "Add Photo";
            this.btnaddimg.UseVisualStyleBackColor = true;
            this.btnaddimg.Click += new System.EventHandler(this.btnaddimg_Click);
            // 
            // btnsubmit
            // 
            this.btnsubmit.Location = new System.Drawing.Point(246, 499);
            this.btnsubmit.Name = "btnsubmit";
            this.btnsubmit.Size = new System.Drawing.Size(103, 33);
            this.btnsubmit.TabIndex = 11;
            this.btnsubmit.Text = "Submit";
            this.btnsubmit.UseVisualStyleBackColor = true;
            this.btnsubmit.Click += new System.EventHandler(this.btnsubmit_Click);
            // 
            // btnclose
            // 
            this.btnclose.Location = new System.Drawing.Point(444, 499);
            this.btnclose.Name = "btnclose";
            this.btnclose.Size = new System.Drawing.Size(75, 34);
            this.btnclose.TabIndex = 12;
            this.btnclose.Text = "Close";
            this.btnclose.UseVisualStyleBackColor = true;
            this.btnclose.Click += new System.EventHandler(this.btnclose_Click);
            // 
            // btnclear
            // 
            this.btnclear.Location = new System.Drawing.Point(591, 498);
            this.btnclear.Name = "btnclear";
            this.btnclear.Size = new System.Drawing.Size(95, 34);
            this.btnclear.TabIndex = 13;
            this.btnclear.Text = "Clear";
            this.btnclear.UseVisualStyleBackColor = true;
            this.btnclear.Click += new System.EventHandler(this.btnclear_Click);
            // 
            // txtfirst
            // 
            this.txtfirst.Location = new System.Drawing.Point(201, 79);
            this.txtfirst.Name = "txtfirst";
            this.txtfirst.Size = new System.Drawing.Size(100, 22);
            this.txtfirst.TabIndex = 14;
            // 
            // txtmiddle
            // 
            this.txtmiddle.Location = new System.Drawing.Point(507, 79);
            this.txtmiddle.Name = "txtmiddle";
            this.txtmiddle.Size = new System.Drawing.Size(148, 22);
            this.txtmiddle.TabIndex = 15;
            // 
            // txtlast
            // 
            this.txtlast.Location = new System.Drawing.Point(815, 78);
            this.txtlast.Name = "txtlast";
            this.txtlast.Size = new System.Drawing.Size(140, 22);
            this.txtlast.TabIndex = 16;
            // 
            // dobpicker
            // 
            this.dobpicker.Location = new System.Drawing.Point(173, 160);
            this.dobpicker.Name = "dobpicker";
            this.dobpicker.Size = new System.Drawing.Size(200, 22);
            this.dobpicker.TabIndex = 17;
            // 
            // txtmobile
            // 
            this.txtmobile.Location = new System.Drawing.Point(507, 160);
            this.txtmobile.Name = "txtmobile";
            this.txtmobile.Size = new System.Drawing.Size(128, 22);
            this.txtmobile.TabIndex = 18;
            // 
            // txtuser
            // 
            this.txtuser.Location = new System.Drawing.Point(173, 324);
            this.txtuser.Name = "txtuser";
            this.txtuser.Size = new System.Drawing.Size(100, 22);
            this.txtuser.TabIndex = 19;
            // 
            // radiomale
            // 
            this.radiomale.AutoSize = true;
            this.radiomale.Location = new System.Drawing.Point(173, 393);
            this.radiomale.Name = "radiomale";
            this.radiomale.Size = new System.Drawing.Size(59, 21);
            this.radiomale.TabIndex = 21;
            this.radiomale.TabStop = true;
            this.radiomale.Text = "Male";
            this.radiomale.UseVisualStyleBackColor = true;
            // 
            // radiofemale
            // 
            this.radiofemale.AutoSize = true;
            this.radiofemale.Location = new System.Drawing.Point(276, 393);
            this.radiofemale.Name = "radiofemale";
            this.radiofemale.Size = new System.Drawing.Size(75, 21);
            this.radiofemale.TabIndex = 22;
            this.radiofemale.TabStop = true;
            this.radiofemale.Text = "Female";
            this.radiofemale.UseVisualStyleBackColor = true;
            // 
            // checkhobby
            // 
            this.checkhobby.FormattingEnabled = true;
            this.checkhobby.Items.AddRange(new object[] {
            "Reding",
            "Writing",
            "Swimming",
            "coding",
            "Gaming",
            "Watching Movies",
            "Listning music"});
            this.checkhobby.Location = new System.Drawing.Point(507, 389);
            this.checkhobby.Name = "checkhobby";
            this.checkhobby.Size = new System.Drawing.Size(179, 72);
            this.checkhobby.TabIndex = 23;
            // 
            // image1
            // 
            this.image1.Location = new System.Drawing.Point(774, 142);
            this.image1.Name = "image1";
            this.image1.Size = new System.Drawing.Size(221, 245);
            this.image1.TabIndex = 24;
            this.image1.TabStop = false;
            // 
            // lblgender
            // 
            this.lblgender.AutoSize = true;
            this.lblgender.Location = new System.Drawing.Point(96, 393);
            this.lblgender.Name = "lblgender";
            this.lblgender.Size = new System.Drawing.Size(68, 17);
            this.lblgender.TabIndex = 25;
            this.lblgender.Text = "Gender : ";
            // 
            // lblhobby
            // 
            this.lblhobby.AutoSize = true;
            this.lblhobby.Location = new System.Drawing.Point(426, 393);
            this.lblhobby.Name = "lblhobby";
            this.lblhobby.Size = new System.Drawing.Size(72, 17);
            this.lblhobby.TabIndex = 26;
            this.lblhobby.Text = "Hobbies : ";
            // 
            // txtaddress
            // 
            this.txtaddress.Location = new System.Drawing.Point(173, 214);
            this.txtaddress.Multiline = true;
            this.txtaddress.Name = "txtaddress";
            this.txtaddress.Size = new System.Drawing.Size(186, 72);
            this.txtaddress.TabIndex = 27;
            // 
            // txtpass
            // 
            this.txtpass.Location = new System.Drawing.Point(444, 324);
            this.txtpass.Name = "txtpass";
            this.txtpass.Size = new System.Drawing.Size(100, 22);
            this.txtpass.TabIndex = 29;
            // 
            // citylist
            // 
            this.citylist.FormattingEnabled = true;
            this.citylist.Items.AddRange(new object[] {
            "Ahmednagar",
            "Akola",
            "Amravati",
            "Aurangabad",
            "Beed",
            "Bhandara",
            "Buldhana",
            "Chandrapur",
            "Dhule",
            "Gadchiroli",
            "Gondia",
            "Hingoli",
            "Jalgaon",
            "Jalna",
            "Kolhapur",
            "Latur",
            "Mumbai City",
            "Mumbai Suburban",
            "Nagpur",
            "Nanded",
            "Nandurbar",
            "Nashik",
            "Osmanabad",
            "Palghar",
            "Parbhani",
            "Pune",
            "Raigad",
            "Ratnagiri",
            "Sangli",
            "Satara",
            "Sindhudurg",
            "Solapur",
            "Thane",
            "Wardha",
            "Washim",
            "Yavatmal"});
            this.citylist.Location = new System.Drawing.Point(485, 234);
            this.citylist.Name = "citylist";
            this.citylist.Size = new System.Drawing.Size(150, 24);
            this.citylist.TabIndex = 30;
            this.citylist.Text = "Select City";
            // 
            // saveFileDialog1
            // 
            this.saveFileDialog1.FileOk += new System.ComponentModel.CancelEventHandler(this.saveFileDialog1_FileOk);
            // 
            // RegistrationFrom
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1060, 544);
            this.Controls.Add(this.citylist);
            this.Controls.Add(this.txtpass);
            this.Controls.Add(this.txtaddress);
            this.Controls.Add(this.lblhobby);
            this.Controls.Add(this.lblgender);
            this.Controls.Add(this.image1);
            this.Controls.Add(this.checkhobby);
            this.Controls.Add(this.radiofemale);
            this.Controls.Add(this.radiomale);
            this.Controls.Add(this.txtuser);
            this.Controls.Add(this.txtmobile);
            this.Controls.Add(this.dobpicker);
            this.Controls.Add(this.txtlast);
            this.Controls.Add(this.txtmiddle);
            this.Controls.Add(this.txtfirst);
            this.Controls.Add(this.btnclear);
            this.Controls.Add(this.btnclose);
            this.Controls.Add(this.btnsubmit);
            this.Controls.Add(this.btnaddimg);
            this.Controls.Add(this.lblpass);
            this.Controls.Add(this.lbluser);
            this.Controls.Add(this.lblcity);
            this.Controls.Add(this.lbladdress);
            this.Controls.Add(this.lblmobile);
            this.Controls.Add(this.lbldob);
            this.Controls.Add(this.lbllast);
            this.Controls.Add(this.lblmiddle);
            this.Controls.Add(this.lblfirst);
            this.Controls.Add(this.label1);
            this.Name = "RegistrationFrom";
            this.Text = "RegistrationForm";
            this.Load += new System.EventHandler(this.RegistrationFrom_Load);
            ((System.ComponentModel.ISupportInitialize)(this.image1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblfirst;
        private System.Windows.Forms.Label lblmiddle;
        private System.Windows.Forms.Label lbllast;
        private System.Windows.Forms.Label lbldob;
        private System.Windows.Forms.Label lblmobile;
        private System.Windows.Forms.Label lbladdress;
        private System.Windows.Forms.Label lblcity;
        private System.Windows.Forms.Label lbluser;
        private System.Windows.Forms.Label lblpass;
        private System.Windows.Forms.Button btnaddimg;
        private System.Windows.Forms.Button btnsubmit;
        private System.Windows.Forms.Button btnclose;
        private System.Windows.Forms.Button btnclear;
        private System.Windows.Forms.TextBox txtfirst;
        private System.Windows.Forms.TextBox txtmiddle;
        private System.Windows.Forms.TextBox txtlast;
        private System.Windows.Forms.DateTimePicker dobpicker;
        private System.Windows.Forms.TextBox txtmobile;
        private System.Windows.Forms.TextBox txtuser;
        private System.Windows.Forms.RadioButton radiomale;
        private System.Windows.Forms.RadioButton radiofemale;
        private System.Windows.Forms.CheckedListBox checkhobby;
        private System.Windows.Forms.PictureBox image1;
        private System.Windows.Forms.Label lblgender;
        private System.Windows.Forms.Label lblhobby;
        private System.Windows.Forms.TextBox txtaddress;
        private System.Windows.Forms.TextBox txtpass;
        private System.Windows.Forms.ComboBox citylist;
        private System.Windows.Forms.SaveFileDialog saveFileDialog1;
    }
}
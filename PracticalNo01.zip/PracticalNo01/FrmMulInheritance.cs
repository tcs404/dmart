﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PracticalNo01
{
    public partial class FrmMulInheritance : Form
    {
        int a, b;
        Calculation cal = new Calculation();
        public FrmMulInheritance()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btnadd_Click(object sender, EventArgs e)
        {
            a = Convert.ToInt32(txtfirst.Text);
            b = Convert.ToInt32(txtsecond.Text);
            lblmsg.Text = "Addition= " + cal.add(a, b);
        }

        private void btnsub_Click(object sender, EventArgs e)
        {
            a = Convert.ToInt32(txtfirst.Text);
            b = Convert.ToInt32(txtsecond.Text);
            lblmsg.Text = "Subtraction= " + cal.sub(a, b);
        }

        private void btnmul_Click(object sender, EventArgs e)
        {
            a = Convert.ToInt32(txtfirst.Text);
            b = Convert.ToInt32(txtsecond.Text);
            lblmsg.Text = "Multiplication= " + cal.mul(a, b);
        }

        private void btndiv_Click(object sender, EventArgs e)
        {
            a = Convert.ToInt32(txtfirst.Text);
            b = Convert.ToInt32(txtsecond.Text);
            lblmsg.Text = "Division= " + cal.div(a, b);
        }

        private void btnclear_Click(object sender, EventArgs e)
        {
            txtfirst.Clear();
            txtsecond.Clear();
        }

        private void btnclose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void FrmMulInheritance_Load(object sender, EventArgs e)
        {

        }
    }
    interface calc1
    {
        int add(int a, int b);
    }
    interface calc2
    {
        int sub(int x, int y);
    }
    interface calc3
    {
        int mul(int r, int s);
    }
    interface calc4
    {
        int div(int c, int d);
    }
    class Calculation : calc1, calc2, calc3, calc4
    {
        public int add(int a, int b)
        {
            return a + b;
        }

        public int div(int a, int b)
        {
            return a / b;
        }

        public int mul(int a, int b)
        {
            return a * b;
        }

        public int sub(int a, int b)
        {
            return a - b;
        }
    }

    }

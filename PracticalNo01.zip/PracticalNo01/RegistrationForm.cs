﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PracticalNo01
{
    public partial class RegistrationFrom : Form
    {
        public RegistrationFrom()
        {
            InitializeComponent();
        }
        string imageLocation;
        private void btnsubmit_Click(object sender, EventArgs e)
        {
            Details d = new Details();
            d.firstName = txtfirst.Text;
            d.middleName = txtmiddle.Text;
            d.lastName = txtlast.Text;

            DateTime dt = this.dobpicker.Value.Date;
            dobpicker.Format = DateTimePickerFormat.Custom;
            dobpicker.CustomFormat = "dd/MM/yyyy";
            dobpicker.ShowUpDown = true;
            d.dob = dobpicker.Value.ToString("dd/MM/yyyy");

            d.mob = txtmobile.Text;
            d.address = txtaddress.Text;
            d.username = txtuser.Text;
            d.passowrd = txtpass.Text;

            if (radiomale.Checked == true)
            {
                d.gender = radiomale.Text;
            }
            else
            {
                d.gender = radiofemale.Text;
            }

            d.path = imageLocation;

            int i;
            string s;
            s = "Hobbies: ";
            for (i = 0; i <= (checkhobby.Items.Count - 1); i++)
            {
                if (checkhobby.GetItemChecked(i))
                {
                    s = s + checkhobby.Items[i].ToString() + ",";
                }
            }
            d.hobbies = s;
            d.city = citylist.SelectedItem.ToString();

            d.ShowDialog();
        }
        public void setPhoto()
        {
            imageLocation = "";
            try
            {
                OpenFileDialog dialog = new OpenFileDialog();
                dialog.Filter = "JPEG files(*.jpeg)|*.jpeg|jpg files(*.jpg)|*.jpg| PNG files(.*.png)|*.png| All files(*.*)|*.*";
                if (dialog.ShowDialog() == System.Windows.Forms.DialogResult.OK)
                {
                    imageLocation = dialog.FileName;
                    image1.ImageLocation = imageLocation;
                }
            }
            catch (Exception)
            {
                MessageBox.Show("An Error Occured", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnaddimg_Click(object sender, EventArgs e)
        {
            setPhoto();
        }



        private void btnclose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnclear_Click(object sender, EventArgs e)
        {
            txtfirst.Clear();
            txtmiddle.Clear();
            txtlast.Clear();
            txtaddress.Clear();
            txtmobile.Clear();
            txtuser.Clear();
            txtpass.Clear();
        }

        private void saveFileDialog1_FileOk(object sender, CancelEventArgs e)
        {

        }

        private void RegistrationFrom_Load(object sender, EventArgs e)
        {

        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PracticalNo01
{
    public partial class FrmWindConversion : Form
    {
        public int knots;
        public FrmWindConversion()
        {
            InitializeComponent();
        }
        SpeedConvert convert = new SpeedConvert();
        private void btnMph_Click(object sender, EventArgs e)
        {
            int knots = Convert.ToInt32(txtKnots.Text);
            lblMsg.Text = "Speed In Miles Per Hour: " + Convert.ToString(convert.convertMph(knots));
        }

        private void btnKph_Click(object sender, EventArgs e)
        {
             int knots = Convert.ToInt32(txtKnots.Text);
            lblMsg.Text = "Speed In Kilometer Per Hour: " + Convert.ToString(convert.convertKph(knots));
        }

        private void FrmWindConversion_Load(object sender, EventArgs e)
        {

        }
    }
    class SpeedConvert
    {
        private double knots;
       
        public SpeedConvert()
        {
            knots = 0;
            
        }
        public SpeedConvert(double k)
        {
            knots = k;

        }
        public  double convertMph(double k)
        {
            return k* 1.1508;
        }
        public double convertKph(double k)
        {
            return k * 1.852;
        }
    }
}
